import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

import seaborn as sb
sb.set_theme()

f, x, y = pd.read_csv("lock_in1.csv").values.transpose()
f1, x1, y1 = pd.read_csv("lock_in.csv").values.transpose()

f = np.concatenate((f, f1))
x = np.concatenate((x, x1))
y = np.concatenate((y, y1))

hack = dict(zip(f, zip(x, y)))
f = np.sort(f)
hack = [hack[a] for a in f]
hack = list(zip(*hack))

x = np.array(hack[0])
y = np.array(hack[1])


def graf(f, x, y):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))
    amp = np.sqrt(x**2 + y**2)
    f_anti = f[np.argmin(amp)]
    delta_f = 10

    ax1.tick_params(direction="in", labelsize=14)
    ax1.set_xscale("log")
    ax1.set_yscale("log")
    ax1.set_xlabel("Frecuencia [Hz]", fontsize=16)
    ax1.set_ylabel("Amplitud [V]", fontsize=16)
    ax1.plot(f, amp, '.')

    ax2.tick_params(direction="in", labelsize=14)
    ax2.plot(f, np.unwrap(np.arctan(y/x), period=np.pi), '.')
    ax2.set_xlabel("Frecuencia [Hz]", fontsize=16)
    ax2.set_ylabel("Fase [rad]", fontsize=16)
    fig.savefig("Plot.pdf")

graf(f, x, y)